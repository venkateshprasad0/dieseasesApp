package com.upgrad.patterns.Interfaces;


public interface IndianDiseaseStat {

    String GetActiveCount();
}
